DROP DATABASE IF EXISTS ciclistas;

CREATE DATABASE IF NOT EXISTS ciclistas;

USE ciclistas;

drop table if exists Ciclista;
drop table if exists Equipo;
drop table if exists Lleva;
drop table if exists Etapa;
drop table if exists Puerto;
drop table if exists Maillot;

CREATE TABLE Equipo (
  nomeq varchar(20) NOT NULL,
  director varchar(50) DEFAULT NULL,
  PRIMARY KEY (nomeq)
);

CREATE TABLE Ciclista (
  dorsal int NOT NULL,
  edad int DEFAULT NULL,
  nombre varchar(50) DEFAULT NULL,
  nomeq varchar(20) DEFAULT NULL,
  PRIMARY KEY (dorsal),
  KEY FK_equipo_iciclistadx (nomeq),
  CONSTRAINT FK_equipo FOREIGN KEY (nomeq) REFERENCES Equipo (nomeq)
) ;

CREATE TABLE Etapa (
  netapa int NOT NULL,
  km int DEFAULT NULL,
  llegada varchar(50) DEFAULT NULL,
  salida varchar(50) DEFAULT NULL,
  dorsal int DEFAULT NULL,
  PRIMARY KEY (netapa),
  KEY FK_ciclista_idx (dorsal),
  CONSTRAINT FK_ciclista FOREIGN KEY (dorsal) REFERENCES Ciclista (dorsal)
) ;

CREATE TABLE Maillot (
  codigo varchar(3) NOT NULL,
  color varchar(20) DEFAULT NULL,
  premio int DEFAULT NULL,
  tipo varchar(20) DEFAULT NULL,
  PRIMARY KEY (codigo)
) ;

CREATE TABLE Lleva (
  codigo varchar(3) NOT NULL,
  netapa int NOT NULL,
  dorsal int DEFAULT NULL,
  PRIMARY KEY (codigo, netapa),
  KEY FK_etapa_idx (netapa),
  KEY FK_ciclista_lleva_idx (dorsal),
  CONSTRAINT FK_ciclista_lleva FOREIGN KEY (dorsal) REFERENCES Ciclista (dorsal),
  CONSTRAINT FK_etapa_lleva FOREIGN KEY (netapa) REFERENCES Etapa (netapa),
  CONSTRAINT FK_maillot_lleva FOREIGN KEY (codigo) REFERENCES Maillot (codigo)
) ;

CREATE TABLE Puerto (
  nompuerto varchar(30) NOT NULL,
  altura int DEFAULT NULL,
  categoria varchar(1) DEFAULT NULL,
  pendiente int DEFAULT NULL,
  netapa int DEFAULT NULL,
  dorsal int DEFAULT NULL,
  PRIMARY KEY (nompuerto),
  KEY FK_etapa_idx (netapa),
  KEY FK_ciclista_idx (dorsal),
  CONSTRAINT FK_ciclista_puerto FOREIGN KEY (dorsal) REFERENCES Ciclista (dorsal),
  CONSTRAINT FK_etapa FOREIGN KEY (netapa) REFERENCES Etapa (netapa)
) ;

-- Tabla Equipos
INSERT INTO Equipo VALUES('Amore Vita','Ricardo Padacci');
INSERT INTO Equipo VALUES('Artiach','Jose Perez');
INSERT INTO Equipo VALUES('Banesto','Miguel Echevarria');
INSERT INTO Equipo VALUES('Bresciali-Refin','Pietro Armani');
INSERT INTO Equipo VALUES('Carrera','Luigi Petroni');
INSERT INTO Equipo VALUES('Castorama','Jean Philip');
INSERT INTO Equipo VALUES('Euskadi','Pedro Txucaru');
INSERT INTO Equipo VALUES('Gatorade','Gian Luca Pacceli');
INSERT INTO Equipo VALUES('Gewiss','Moreno Argentin');
INSERT INTO Equipo VALUES('Jolly Club','Johan Richard');
INSERT INTO Equipo VALUES('Kelme','Alvaro Pino');
INSERT INTO Equipo VALUES('Lotus Festina','Suarez Cuevas');
INSERT INTO Equipo VALUES('Mapei-Clas','Juan Fernandez');
INSERT INTO Equipo VALUES('Mercatone Uno','Ettore Romano');
INSERT INTO Equipo VALUES('Motorola','John Fidwell');
INSERT INTO Equipo VALUES('Navigare','Lonrenzo Sciacci');
INSERT INTO Equipo VALUES('ONCE','Manuel Sainz');
INSERT INTO Equipo VALUES('PDM','Piet Van Der Kruis');
INSERT INTO Equipo VALUES('Seguros Amaya','Minguez');
INSERT INTO Equipo VALUES('Telecom','Morgan Reikcard');
INSERT INTO Equipo VALUES('TVM','Steveens Henk');
INSERT INTO Equipo VALUES('Wordperfect','Bill Gates');

-- Tabla ciclistas
INSERT INTO Ciclista VALUES(1,32,'Miguel Indurain','Banesto');
INSERT INTO Ciclista VALUES(2,35,'Pedro Delgado','Banesto');
INSERT INTO Ciclista VALUES(3,27,'Alex Zulle','ONCE');
INSERT INTO Ciclista VALUES(4,30,'Tony Rominger','Mapei-Clas');
INSERT INTO Ciclista VALUES(5,32,'Gert-Jan Theunisse','TVM');
INSERT INTO Ciclista VALUES(6,33,'Adriano Baffi','Mercatone Uno');
INSERT INTO Ciclista VALUES(7,30,'Massimiliano Lelli','Mercatone Uno');
INSERT INTO Ciclista VALUES(8,33,'Jean Van Poppel','Lotus Festina');
INSERT INTO Ciclista VALUES(9,34,'Massimo Podenzana','Navigare');
INSERT INTO Ciclista VALUES(10,28,'Mario Cipollini','Mercatone Uno');
INSERT INTO Ciclista VALUES(11,31,'Flavio Giupponi','Bresciali-Refin');
INSERT INTO Ciclista VALUES(12,31,'Alessio Di Basco','Amore Vita');
INSERT INTO Ciclista VALUES(13,28,'Lale Cubino','Seguros Amaya');
INSERT INTO Ciclista VALUES(14,33,'Roberto Pagnin','Navigare');
INSERT INTO Ciclista VALUES(15,31,'Jesper Skibby','TVM');
INSERT INTO Ciclista VALUES(16,29,'Dimitri Konishev','Jolly Club');
INSERT INTO Ciclista VALUES(17,37,'Bruno Leali','Bresciali-Refin');
INSERT INTO Ciclista VALUES(18,37,'Robert Millar','TVM');
INSERT INTO Ciclista VALUES(19,34,'Julian Gorospe','Banesto');
INSERT INTO Ciclista VALUES(20,29,'Alfonso Guti\u00e9rrez','Artiach');
INSERT INTO Ciclista VALUES(21,31,'Erwin Nijboer','Artiach');
INSERT INTO Ciclista VALUES(22,32,'Giorgio Furlan','Gewiss');
INSERT INTO Ciclista VALUES(23,27,'Lance Armstrong','Motorola');
INSERT INTO Ciclista VALUES(24,29,'Claudio Chiappucci','Carrera');
INSERT INTO Ciclista VALUES(25,32,'Gianni Bugno','Gatorade');
INSERT INTO Ciclista VALUES(26,27,'Mikel Zarrabeitia','Banesto');
INSERT INTO Ciclista VALUES(27,28,'Laurent Jalabert','ONCE');
INSERT INTO Ciclista VALUES(28,33,'Jesus Montoya','Banesto');
INSERT INTO Ciclista VALUES(29,28,'Angel Edo','Kelme');
INSERT INTO Ciclista VALUES(30,28,'Melchor Mauri','Banesto');
INSERT INTO Ciclista VALUES(31,30,'Vicente Aparicio','Banesto');
INSERT INTO Ciclista VALUES(32,28,'Laurent Dufaux','ONCE');
INSERT INTO Ciclista VALUES(33,29,'Stefano della Santa','Mapei-Clas');
INSERT INTO Ciclista VALUES(34,30,'Angel Yesid Camargo','Kelme');
INSERT INTO Ciclista VALUES(35,28,'Erik Dekker','Wordperfect');
INSERT INTO Ciclista VALUES(36,32,'Gian Matteo Fagnini','Mercatone Uno');
INSERT INTO Ciclista VALUES(37,29,'Scott Sunderland','TVM');
INSERT INTO Ciclista VALUES(38,25,'Javier Palacin','Euskadi');
INSERT INTO Ciclista VALUES(39,30,'Rudy Verdonck','Lotus Festina');
INSERT INTO Ciclista VALUES(40,32,'Viatceslav Ekimov','Wordperfect');
INSERT INTO Ciclista VALUES(41,25,'Rolf Aldag','Telecom');
INSERT INTO Ciclista VALUES(42,29,'Davide Cassani','TVM');
INSERT INTO Ciclista VALUES(43,28,'Francesco Casagrande','Mercatone Uno');
INSERT INTO Ciclista VALUES(44,27,'Luca Gelfi','Gatorade');
INSERT INTO Ciclista VALUES(45,26,'Alberto Elli','Artiach');
INSERT INTO Ciclista VALUES(46,24,'Agustin Sagasti','Euskadi');
INSERT INTO Ciclista VALUES(47,32,'Laurent Pillon','Gewiss');
INSERT INTO Ciclista VALUES(48,29,'Marco Saligari','Gewiss');
INSERT INTO Ciclista VALUES(49,23,'Eugeni Berzin','Gewiss');
INSERT INTO Ciclista VALUES(50,27,'Fernando Escartin','Mapei-Clas');
INSERT INTO Ciclista VALUES(51,30,'Udo Bolts','Telecom');
INSERT INTO Ciclista VALUES(52,26,'Vladislav Bobrik','Gewiss');
INSERT INTO Ciclista VALUES(53,28,'Michele Bartoli','Mercatone Uno');
INSERT INTO Ciclista VALUES(54,30,'Steffen Wesemann','Telecom');
INSERT INTO Ciclista VALUES(55,28,'Nicola Minali','Gewiss');
INSERT INTO Ciclista VALUES(56,29,'Andrew Hampsten','Banesto');
INSERT INTO Ciclista VALUES(57,28,'Stefano Zanini','Navigare');
INSERT INTO Ciclista VALUES(58,34,'Gerd Audehm','Telecom');
INSERT INTO Ciclista VALUES(59,28,'Mariano Picolli','Mercatone Uno');
INSERT INTO Ciclista VALUES(60,28,'Giovanni Lombardi','Bresciali-Refin');
INSERT INTO Ciclista VALUES(61,26,'Walte Castignola','Navigare');
INSERT INTO Ciclista VALUES(62,30,'Raul Alcala','Motorola');
INSERT INTO Ciclista VALUES(63,32,'Alvaro Mejia','Motorola');
INSERT INTO Ciclista VALUES(64,28,'Giuseppe Petito','Mercatone Uno');
INSERT INTO Ciclista VALUES(65,29,'Pascal Lino','Amore Vita');
INSERT INTO Ciclista VALUES(66,24,'Enrico Zaina','Gewiss');
INSERT INTO Ciclista VALUES(67,28,'Armand de las Cuevas','Castorama');
INSERT INTO Ciclista VALUES(68,28,'Angel Citracca','Navigare');
INSERT INTO Ciclista VALUES(69,27,'Eddy Seigneur','Castorama');
INSERT INTO Ciclista VALUES(70,29,'Sandro Heulot','Banesto');
INSERT INTO Ciclista VALUES(71,27,'Prudencio Indur\u00e1in','Banesto');
INSERT INTO Ciclista VALUES(72,28,'Stefano Colage','Bresciali-Refin');
INSERT INTO Ciclista VALUES(73,35,'Laurent Fignon','Gatorade');
INSERT INTO Ciclista VALUES(74,36,'Claudio Chioccioli','Amore Vita');
INSERT INTO Ciclista VALUES(75,32,'Juan Romero','Seguros Amaya');
INSERT INTO Ciclista VALUES(76,34,'Marco Giovannetti','Gatorade');
INSERT INTO Ciclista VALUES(77,33,'Javier Mauleon','Mapei-Clas');
INSERT INTO Ciclista VALUES(78,35,'Antonio Esparza','Kelme');
INSERT INTO Ciclista VALUES(79,33,'Johan Bruyneel','ONCE');
INSERT INTO Ciclista VALUES(80,37,'Federico Echave','Mapei-Clas');
INSERT INTO Ciclista VALUES(81,33,'Piotr Ugrumov','Gewiss');
INSERT INTO Ciclista VALUES(82,30,'Edgar Corredor','Kelme');
INSERT INTO Ciclista VALUES(83,32,'Hernan Buenahora','Kelme');
INSERT INTO Ciclista VALUES(84,31,'Jon Unzaga','Mapei-Clas');
INSERT INTO Ciclista VALUES(85,30,'Dimitri Abdoujaparov','Carrera');
INSERT INTO Ciclista VALUES(86,32,'Juan Martinez Oliver','Kelme');
INSERT INTO Ciclista VALUES(87,32,'Fernando Mota','Artiach');
INSERT INTO Ciclista VALUES(88,28,'Angel Camarillo','Mapei-Clas');
INSERT INTO Ciclista VALUES(89,36,'Stefan Roche','Carrera');
INSERT INTO Ciclista VALUES(90,27,'Ivan Ivanov','Artiach');
INSERT INTO Ciclista VALUES(91,28,'Nestor Mora','Kelme');
INSERT INTO Ciclista VALUES(92,27,'Federico Garcia','Artiach');
INSERT INTO Ciclista VALUES(93,29,'Bo Hamburger','TVM');
INSERT INTO Ciclista VALUES(94,30,'Marino Alonso','Banesto');
INSERT INTO Ciclista VALUES(95,31,'Manuel Guijarro','Lotus Festina');
INSERT INTO Ciclista VALUES(96,29,'Tom Cordes','Wordperfect');
INSERT INTO Ciclista VALUES(97,28,'Casimiro Moreda','ONCE');
INSERT INTO Ciclista VALUES(98,25,'Eleuterio Anguita','Artiach');
INSERT INTO Ciclista VALUES(99,29,'Per Pedersen','Seguros Amaya');
INSERT INTO Ciclista VALUES(100,30,'William Palacios','Jolly Club');

-- Tabla etapa
INSERT INTO Etapa VALUES(1,9,'Valladolid','Valladolid',1);
INSERT INTO Etapa VALUES(2,180,'Salamanca','Valladolid',36);
INSERT INTO Etapa VALUES(3,240,'Caceres','Salamanca',12);
INSERT INTO Etapa VALUES(4,230,'Cordoba','Almendralejo',83);
INSERT INTO Etapa VALUES(5,170,'Granada','Cordoba',27);
INSERT INTO Etapa VALUES(6,150,'Sierra Nevada','Granada',52);
INSERT INTO Etapa VALUES(7,250,'Alicante','Baza',22);
INSERT INTO Etapa VALUES(8,40,'Benidorm','Benidorm',1);
INSERT INTO Etapa VALUES(9,150,'Valencia','Benidorm',35);
INSERT INTO Etapa VALUES(10,200,'Andorra','Igualada',2);
INSERT INTO Etapa VALUES(11,195,'Estacion de Cerler','Andorra',65);
INSERT INTO Etapa VALUES(12,220,'Zaragoza','Benasque',12);
INSERT INTO Etapa VALUES(13,200,'Pamplona','Zaragoza',93);
INSERT INTO Etapa VALUES(14,172,'Alto de la Cruz de la Demanda','Pamplona',86);
INSERT INTO Etapa VALUES(15,207,'Santander','Santo Domingo de la Calzada',10);
INSERT INTO Etapa VALUES(16,160,'Lagos de Covadonga','Santander',5);
INSERT INTO Etapa VALUES(17,140,'Alto del Naranco','Cangas de Onis',4);
INSERT INTO Etapa VALUES(18,195,'Avila','Avila',8);
INSERT INTO Etapa VALUES(19,190,'Destilerias Dyc','Avila',2);
INSERT INTO Etapa VALUES(20,52,'Destilerias Dyc','Segovia',2);
INSERT INTO Etapa VALUES(21,170,'Madrid','Destilerias Dyc',27);

-- Tabla maillot
INSERT INTO Maillot VALUES('MGE','amarillo',8000000,'General');
INSERT INTO Maillot VALUES('MMO','blanco y rojo',2000000,'Montaña');
INSERT INTO Maillot VALUES('MMS','estrellas moradas',2000000,'Mas Sufrido');
INSERT INTO Maillot VALUES('MMV','rojo',2000000,'Metas volantes');
INSERT INTO Maillot VALUES('MRE','verde',2000000,'Regularidad');
INSERT INTO Maillot VALUES('MSE','rosa',2000000,'Sprints especiales');

-- Tabla lleva
INSERT INTO Lleva VALUES('MGE',1,1);
INSERT INTO Lleva VALUES('MGE',2,1);
INSERT INTO Lleva VALUES('MGE',3,1);
INSERT INTO Lleva VALUES('MGE',4,1);
INSERT INTO Lleva VALUES('MGE',5,2);
INSERT INTO Lleva VALUES('MGE',6,2);
INSERT INTO Lleva VALUES('MGE',7,2);
INSERT INTO Lleva VALUES('MGE',8,4);
INSERT INTO Lleva VALUES('MGE',9,26);
INSERT INTO Lleva VALUES('MGE',10,26);
INSERT INTO Lleva VALUES('MGE',11,3);
INSERT INTO Lleva VALUES('MGE',12,3);
INSERT INTO Lleva VALUES('MGE',13,30);
INSERT INTO Lleva VALUES('MGE',14,30);
INSERT INTO Lleva VALUES('MGE',15,30);
INSERT INTO Lleva VALUES('MGE',16,1);
INSERT INTO Lleva VALUES('MGE',17,1);
INSERT INTO Lleva VALUES('MGE',18,1);
INSERT INTO Lleva VALUES('MGE',19,1);
INSERT INTO Lleva VALUES('MGE',20,1);
INSERT INTO Lleva VALUES('MGE',21,1);
INSERT INTO Lleva VALUES('MMO',1,1);
INSERT INTO Lleva VALUES('MMO',2,25);
INSERT INTO Lleva VALUES('MMO',3,25);
INSERT INTO Lleva VALUES('MMO',4,24);
INSERT INTO Lleva VALUES('MMO',5,25);
INSERT INTO Lleva VALUES('MMO',6,26);
INSERT INTO Lleva VALUES('MMO',7,26);
INSERT INTO Lleva VALUES('MMO',8,26);
INSERT INTO Lleva VALUES('MMO',9,26);
INSERT INTO Lleva VALUES('MMO',10,30);
INSERT INTO Lleva VALUES('MMO',11,30);
INSERT INTO Lleva VALUES('MMO',12,30);
INSERT INTO Lleva VALUES('MMO',13,30);
INSERT INTO Lleva VALUES('MMO',14,28);
INSERT INTO Lleva VALUES('MMO',15,28);
INSERT INTO Lleva VALUES('MMO',16,28);
INSERT INTO Lleva VALUES('MMO',17,28);
INSERT INTO Lleva VALUES('MMO',18,26);
INSERT INTO Lleva VALUES('MMO',19,28);
INSERT INTO Lleva VALUES('MMO',20,28);
INSERT INTO Lleva VALUES('MMO',21,2);
INSERT INTO Lleva VALUES('MMS',1,67);
INSERT INTO Lleva VALUES('MMS',2,69);
INSERT INTO Lleva VALUES('MMS',3,67);
INSERT INTO Lleva VALUES('MMS',4,69);
INSERT INTO Lleva VALUES('MMV',1,1);
INSERT INTO Lleva VALUES('MMV',2,16);
INSERT INTO Lleva VALUES('MMV',3,16);
INSERT INTO Lleva VALUES('MMV',4,17);
INSERT INTO Lleva VALUES('MMV',5,16);
INSERT INTO Lleva VALUES('MMV',6,16);
INSERT INTO Lleva VALUES('MMV',7,33);
INSERT INTO Lleva VALUES('MMV',8,33);
INSERT INTO Lleva VALUES('MMV',9,48);
INSERT INTO Lleva VALUES('MMV',10,48);
INSERT INTO Lleva VALUES('MMV',11,48);
INSERT INTO Lleva VALUES('MMV',12,48);
INSERT INTO Lleva VALUES('MMV',13,48);
INSERT INTO Lleva VALUES('MMV',14,42);
INSERT INTO Lleva VALUES('MMV',15,42);
INSERT INTO Lleva VALUES('MMV',16,42);
INSERT INTO Lleva VALUES('MMV',17,42);
INSERT INTO Lleva VALUES('MMV',18,20);
INSERT INTO Lleva VALUES('MMV',19,42);
INSERT INTO Lleva VALUES('MMV',20,42);
INSERT INTO Lleva VALUES('MMV',21,42);
INSERT INTO Lleva VALUES('MRE',1,1);
INSERT INTO Lleva VALUES('MRE',2,27);
INSERT INTO Lleva VALUES('MRE',3,27);
INSERT INTO Lleva VALUES('MRE',4,27);
INSERT INTO Lleva VALUES('MRE',5,27);
INSERT INTO Lleva VALUES('MRE',6,20);
INSERT INTO Lleva VALUES('MRE',7,20);
INSERT INTO Lleva VALUES('MRE',8,20);
INSERT INTO Lleva VALUES('MRE',9,20);
INSERT INTO Lleva VALUES('MRE',10,20);
INSERT INTO Lleva VALUES('MRE',11,20);
INSERT INTO Lleva VALUES('MRE',12,20);
INSERT INTO Lleva VALUES('MRE',13,20);
INSERT INTO Lleva VALUES('MRE',14,20);
INSERT INTO Lleva VALUES('MRE',15,20);
INSERT INTO Lleva VALUES('MRE',16,20);
INSERT INTO Lleva VALUES('MRE',17,20);
INSERT INTO Lleva VALUES('MRE',18,27);
INSERT INTO Lleva VALUES('MRE',19,20);
INSERT INTO Lleva VALUES('MRE',20,20);
INSERT INTO Lleva VALUES('MRE',21,20);
INSERT INTO Lleva VALUES('MSE',1,1);
INSERT INTO Lleva VALUES('MSE',2,8);
INSERT INTO Lleva VALUES('MSE',3,12);
INSERT INTO Lleva VALUES('MSE',4,8);
INSERT INTO Lleva VALUES('MSE',5,12);
INSERT INTO Lleva VALUES('MSE',6,12);
INSERT INTO Lleva VALUES('MSE',7,99);
INSERT INTO Lleva VALUES('MSE',8,99);
INSERT INTO Lleva VALUES('MSE',9,99);
INSERT INTO Lleva VALUES('MSE',10,99);
INSERT INTO Lleva VALUES('MSE',11,99);
INSERT INTO Lleva VALUES('MSE',12,99);
INSERT INTO Lleva VALUES('MSE',13,99);
INSERT INTO Lleva VALUES('MSE',14,22);
INSERT INTO Lleva VALUES('MSE',15,22);
INSERT INTO Lleva VALUES('MSE',16,22);
INSERT INTO Lleva VALUES('MSE',17,22);
INSERT INTO Lleva VALUES('MSE',18,10);
INSERT INTO Lleva VALUES('MSE',19,22);
INSERT INTO Lleva VALUES('MSE',20,22);
INSERT INTO Lleva VALUES('MSE',21,22);

-- Tabla puertos
INSERT INTO Puerto VALUES('Alto del Naranco',565,'1',6.9E0,10,30);
INSERT INTO Puerto VALUES('Arcalis',2230,'E',6.5E0,10,4);
INSERT INTO Puerto VALUES('Cerler-Circo de Ampriu',2500,'E',5.87E0,11,9);
INSERT INTO Puerto VALUES('Coll de la Comella',1362,'1',8.07E0,10,2);
INSERT INTO Puerto VALUES('Coll de Ordino',1980,'E',5.3E0,10,7);
INSERT INTO Puerto VALUES('Cruz de la Demanda',1850,'E',7.0E0,11,20);
INSERT INTO Puerto VALUES('Lagos de Covadonga',1134,'E',6.86E0,16,42);
INSERT INTO Puerto VALUES('Navacerrada',1860,'1',7.5E0,19,2);
INSERT INTO Puerto VALUES('Puerto de Alisas',672,'1',5.8E0,15,1);
INSERT INTO Puerto VALUES('Puerto de la Morcuera',1760,'2',6.5E0,19,2);
INSERT INTO Puerto VALUES('Puerto de Mijares',1525,'1',4.9E0,18,24);
INSERT INTO Puerto VALUES('Puerto de Navalmoral',1521,'2',4.3E0,18,2);
INSERT INTO Puerto VALUES('Puerto de Pedro Bernardo',1250,'1',4.2E0,18,25);
INSERT INTO Puerto VALUES('Sierra Nevada',2500,'E',6.0E0,2,26);
